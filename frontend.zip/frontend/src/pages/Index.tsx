import { ChatLayout } from "@/components/layout/ChatLayout";

const Index = () => {
  return <ChatLayout />;
};

export default Index;